/*
 *  Copyright (c) 2011, 2014 Freescale Semiconductor, Inc.
 *
 *  THIS FILE IS CONFIDENTIAL.
 *
 *  AUTHORIZED USE IS GOVERNED BY CONFIDENTIALITY AND LICENSE AGREEMENTS WITH FREESCALE SEMICONDUCTOR, INC.
 *
 *  UNAUTHORIZED COPIES AND USE ARE STRICTLY PROHIBITED AND MAY RESULT IN CRIMINAL AND/OR CIVIL PROSECUTION.
 */

#include "ipv6.h"

static int ipv6_cmp_aligned(void *src, void *dst)
{
	u32 off = 0;

	if ((unsigned long)src & 0x2) {
		if (*(u16 *)src - *(u16 *)dst)
			return 1;

		off = 2;
		src += 2;
		dst += 2;
	}

	if ((*(u32 *)(src + 0) - *(u32 *)(dst + 0)) ||
	    (*(u32 *)(src + 4) - *(u32 *)(dst + 4)) ||
	    (*(u32 *)(src + 8) - *(u32 *)(dst + 8)))
		return 1;

	if (off)
		return (*(u16 *)(src + 12) - *(u16 *)(dst + 12)) ? 1 : 0;
	else
		return (*(u32 *)(src + 12) - *(u32 *)(dst + 12)) ? 1 : 0;
}

static int ipv6_cmp_unaligned(void *src, void *dst)
{
	return ((*(u32 *)(src + 0) - READ_UNALIGNED_INT(*(u32 *)(dst + 0))) ||
		(*(u32 *)(src + 4) - READ_UNALIGNED_INT(*(u32 *)(dst + 4))) ||
		(*(u32 *)(src + 8) - READ_UNALIGNED_INT(*(u32 *)(dst + 8))) ||
		(*(u32 *)(src + 12) - READ_UNALIGNED_INT(*(u32 *)(dst + 12))));
}

int ipv6_cmp(void *src, void *dst)
{
	if (((unsigned long)src & 0x3) == ((unsigned long)dst & 0x3))
		return ipv6_cmp_aligned(src, dst);
	else {
		if ((unsigned long)src & 0x3)
			return ipv6_cmp_unaligned(dst, src);
		else
			return ipv6_cmp_unaligned(src, dst);
	}
}

